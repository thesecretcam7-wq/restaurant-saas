@echo off
cd /d "%~dp0"
echo Instalando Eccofood Print Agent...
echo.
echo IMPORTANTE: si Windows pregunta permisos, pulsa SI.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0sistema\install.ps1"
echo.
pause
